import { expect, Page } from '../node_modules/@playwright/test';

export class assertionLibrary {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }
  async verifyElementText(locator: string, text: string): Promise<void> {
    const textValue = await this.page.textContent(locator);
    expect(textValue.trim()).toBe(text);
  }
  async verifyElementContainsText(
    locator: string,
    text: string,
  ): Promise<void> {
    await expect(this.page.locator(locator)).toContainText(text);
  }
  async verifyJSElementValue(locator: string, text: string): Promise<void> {
    const textValue = await this.page.$eval(
      locator,
      (element: HTMLInputElement) => element.value,
    );
    expect(textValue.trim()).toBe(text);
  }
  async verifyElementAttribute(
    locator: string,
    attribute: string,
    value: string,
  ): Promise<void> {
    const textValue = await this.page.getAttribute(locator, attribute);
    expect(textValue.trim()).toBe(value);
  }
  async expectToBeTrue(status: boolean, errorMessage: string): Promise<void> {
    expect(status, `${errorMessage}`).toBe(true);
  }

  async expectToBeValue(
    expectedValue: string,
    actualValue: string,
    errorMessage: string,
  ): Promise<void> {
    expect(expectedValue.trim(), `${errorMessage}`).toBe(actualValue);
  }
}
