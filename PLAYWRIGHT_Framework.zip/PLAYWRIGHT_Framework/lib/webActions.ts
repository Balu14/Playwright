// playwright-dev-page.ts
import { Page, expect, BrowserContext } from '@playwright/test';
import { testConfig } from '../testConfig';
const waitForElement = testConfig.waitForElement;

export class webActions {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async navigateToURL(url: string) {
    this.page.goto(url);
  }

  async delay(time: number): Promise<void> {
    return new Promise(function (resolve) {
      setTimeout(resolve, time);
    });
  }

  async clickElement(locator: string): Promise<void> {
    await this.page.click(locator);
  }
  async clickContainsElement(text: string): Promise<void> {
    await this.page.locator('//div[contains(text(),"' + text + '")]').click();
  }
  async clickOnGetByRoleElement(text: string): Promise<void> {
    await this.page.getByRole('option', { name: text }).click();
  }

  async enterElementText(locator: string, text: string): Promise<void> {
    await this.page.fill(locator, text);
  }
  async waitForContainsSelectorsLocator(text: string): Promise<void> {
    await this.page.waitForSelector('//*[contains(text(),"' + text + '")]');
  }
  async dragAndDrop(
    dragElementLocator: string,
    dropElementLocator: string,
  ): Promise<void> {
    await this.page.dragAndDrop(dragElementLocator, dropElementLocator);
  }

  async keyPress(locator: string, key: string): Promise<void> {
    this.page.press(locator, key);
  }

  async verifyNewWindowUrlAndClick(
    context: BrowserContext,
    newWindowLocator: string,
    urlText: string,
    clickOnNewWindowLocator: string,
  ): Promise<void> {
    const [newPage] = await Promise.all([
      context.waitForEvent('page'),
      this.page.click(newWindowLocator),
    ]);
    await newPage.waitForLoadState();
    expect(newPage.url()).toContain(urlText);
    await newPage.click(clickOnNewWindowLocator);
    await newPage.close();
  }
  async waitForPageNavigation(event: string): Promise<void> {
    switch (event.toLowerCase()) {
      case `networkidle`:
        await this.page.waitForNavigation({
          waitUntil: `networkidle`,
          timeout: waitForElement,
        });
        break;
      case `load`:
        await this.page.waitForNavigation({
          waitUntil: `load`,
          timeout: waitForElement,
        });
        break;
      case `domcontentloaded`:
        await this.page.waitForNavigation({
          waitUntil: `domcontentloaded`,
          timeout: waitForElement,
        });
    }
  }
  async enterElementTextInsideFrame(
    frame: string,
    locator: string,
    text: string,
  ): Promise<void> {
    const username = await this.page.frameLocator(frame).getByLabel(locator);
    await username.fill(text);
  }
  async takeScreenShot() {
    let value = Math.floor(Math.random() * 100000);
    let ss = `./screenshot/${value}.png`;
    await this.page.screenshot({
      path: ss,
    });
  }
  async fileUpload(locator: string, fileName: string) {
    await this.page.setInputFiles(locator, fileName);
  }
  async filesUpload(locator: string, filesname: string[]) {
    await this.page.locator(locator).setInputFiles(filesname);
  }
}
