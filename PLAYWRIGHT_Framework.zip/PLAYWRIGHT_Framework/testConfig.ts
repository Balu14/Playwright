export const testConfig = {
  qa: `https://opensource-demo.orangehrmlive.com/web/index.php/auth/login`,
  dev: ``,
  qaApi: `https://reqres.in`,
  devApi: ``,
  username: `Admin`,
  password: `admin123`,
  waitForElement: 120000,
};
