# Playwright-Cucumber-Framework

This framework was develped using Cucumber with Playwright using Typescript. With default reports of Playwright(HTML, Line) and Cucumber report along with Allure report integration as well. Test data can be passed using JSON file and passing data using feature file.

## Use of Playwright-Cucumber-Framework project?

The use of this Framework is to perform the End to End Testing, API testing, Visual testing using Playwright.

## What's inside

- Typescript setup for writing steps with eslint/typescript and prettier
- Launching of Playwright browser before running all tests
- Cucumber BDD testing.
- Launching new context and page for each scenario
- Running feature with video recording option
- Report generated with last good image attached
- Allure reports, Playwright HTML Report, Cucumber Report
- Utilies function to help you to reuse the exiting funtions
- Lib if used to keep the generic function which will be used across all modeules
- VScode configuration to debug a single feature or an only scenario (run when located on the feature file)

## To run your tests

`npm run test` or `npx cucumber-js` runs all tests
`npm run test <feature name>` or `npx cucumber-js <feature name>` run the single feature
`npx playwright test` to run all test files in playwright
`npx playwright test <testcase name>` to run single test script

## Browser selection

By default it will run in chromium. You can define an envrionment variable called BROWSER and
set the name of the browser. Available options: chromium, firefox, webkit

set BROWSER=firefox
npm run test

````

## Working with Page Objects

Page object model has been implemented for each page in the application there is a corresponding page class has been developed in pageobjects folder.
The objects are inside ObjectRepository folder.

## Debugging Features

`npx playwright test <testcase name> --debug` to run single test script in debug mode

## In Visual Studio Code

- Open the feature
- Select the debug options in the VSCode debugger
- Set breakpoints in the code

To stop the feature, you can add the `Then debug` step inside your feature. It will stop your debugger.

## To choose a reporter

The last reporter/formatter found on the cucumber-js command-line wins:

```text
--format summary --format @cucumber/pretty-formatter --format cucumber-console-formatter
````

In [cucumber.mjs](cucumber.mjs) file, modify the options.

To use Allure reporting, you can run with env param: `USE_ALLURE=1`, and then use the `npm run allure` to show the report.

## To ignore a scenario

- tag the scenario with `@ignore`

## To check for typescript, linting and gherkin errors

- run the command `npm run build`.

## To view the steps usage

- run the command `npm run steps-usage`.

## To view the html report of the last run

- run the command `npm run report`.

## To view allure report

- run the command `npm run allure`.

## Test scripts Grouping

- run the command `npx playwright test --grep "@Regression"`.

## Test scripts to skip some

- run the command `npx playwright test --grep-invert "@Regression"`.
