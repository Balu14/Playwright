import { test } from '@playwright/test';
import { assertionLibrary } from '../../lib/assertionLibrary';

test('API Testing', async ({ request }) => {
  const assertionLibraryPage = new assertionLibrary();

  const responce = await request.get('http://ip.jsontest.com/');
  //assertionLibraryPage.verifyStatusCode(responce);
});
