import { request, test } from '@playwright/test';

test(`Validate Post API response`, async ({ request }) => {
  const response = await request.post('https://reqres.in/api/users', {
    data: {
      id: 555,
    },
  });
});
