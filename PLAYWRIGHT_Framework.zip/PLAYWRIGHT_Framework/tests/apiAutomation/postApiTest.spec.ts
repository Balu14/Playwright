import { apiActions } from '../../lib/apiActions';
import { test } from '@playwright/test';

const apiAction = new apiActions();

test(`@API postUsers`, async ({ request }) => {
  //* Body Response Params and Body Response Headers are stored in single text file separated by #
  const requestBody = JSON.parse(
    (await apiAction.readValuesFromTextFile('postUsers')).split(`#`)[0],
  );
  const response = await request.post(`/api/users`, { data: requestBody });
  await apiAction.verifyStatusCode(response);

  const responseBodyParams = (
    await apiAction.readValuesFromTextFile(`postUsers`)
  ).split(`#`)[1];
  await apiAction.verifyResponseBody(
    responseBodyParams,
    await response.json(),
    `Response Body`,
  );

  const responseBodyHeaders = (
    await apiAction.readValuesFromTextFile(`postUsers`)
  ).split(`#`)[2];
  await apiAction.verifyResponseHeader(
    responseBodyHeaders,
    response.headersArray(),
    `Respomse Headers`,
  );
});
