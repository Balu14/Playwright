import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';

test.describe('Test for Groping', () => {
  test('Script for @Smoke test', async ({ page }) => {
    const login = new loginPage(page);
    await login.gotoApplication();
    console.log('Test from Smoke');
  });
  test('Script for @Regression test', async ({ page }) => {
    const login = new loginPage(page);
    await login.gotoApplication();
    console.log('Test from Regression');
  });
});
