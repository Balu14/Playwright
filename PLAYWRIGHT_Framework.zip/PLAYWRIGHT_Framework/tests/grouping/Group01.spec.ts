import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';

test('Login to the Application @fast', async ({ page }) => {
  const login = new loginPage(page);
  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLogin();
});

test('Go to the Application @slow', async ({ page }) => {
  const login = new loginPage(page);
  await login.gotoApplication();
});
