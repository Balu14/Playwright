import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';

test('Login to the Application and Take Screenshot', async ({ page }) => {
  const login = new loginPage(page);

  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLoginWithScreenShot();
});
