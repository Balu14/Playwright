import { test } from '@playwright/test';
import { webActions } from '../../lib/webActions';

test.only('Multiple Files Upload', async ({ page }) => {
  const action = new webActions(page);
  await page.goto('http://autopract.com/selenium/upload1/');

  await action.filesUpload("input[type='file']", [
    'files/play.png',
    'files/wright.png',
  ]);
  await page.locator("button[type='submit']").click();
});
test('Single File Upload', async ({ page }) => {
  await page.goto('http://www.autopract.com');

  await page.locator('.close').click();

  await page.setInputFiles("input[type='file']", 'files/wright.png');

  await page.locator('.btn.btn-success').click();
});
