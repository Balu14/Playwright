import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';
import { searchUserPage } from '../../src/pageobjects/searchUserPage';
import * as data from '../../src/testdata/data.json';

for (let i = 0; i < data.TestCase02.length; i++) {
  test(`Validate login to application using different users ${data.TestCase02[i].number}`, async ({
    page,
  }) => {
    const login = new loginPage(page);
    const search = new searchUserPage(page);

    await login.gotoApplication();
    await login.logintoApplication();
    await login.assertionForLogin();
    await search.searchForUser(
      data.TestCase02[i].User,
      data.TestCase02[i].expectName,
    );
  });
}
