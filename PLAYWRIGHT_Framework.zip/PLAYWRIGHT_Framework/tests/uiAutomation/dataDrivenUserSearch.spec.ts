import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';
import { searchUserPage } from '../../src/pageobjects/searchUserPage';
import * as UserSearchData from '../../src/testdata/UserSearchData.json';

test(`Validate login to application using different users${UserSearchData.testCaseNum}`, async ({
  page,
}) => {
  const login = new loginPage(page);
  const search = new searchUserPage(page);

  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLogin();
  await search.searchForUser(UserSearchData.User, UserSearchData.expectName);
});
