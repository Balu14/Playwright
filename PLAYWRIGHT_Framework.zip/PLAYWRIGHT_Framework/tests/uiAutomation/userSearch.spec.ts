import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';
import { searchUserPage } from '../../src/pageobjects/searchUserPage';

test('Search for a User in Admin', async ({ page }) => {
  const login = new loginPage(page);
  const search = new searchUserPage(page);
  const User = 'David Morris';
  const expectName = 'David Morris';

  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLogin();
  await search.searchForUser(User, expectName);
});
