import { pageObjectManager } from '../../src/pageobjects/pageObjectManager';
import { test } from '@playwright/test';
import * as data from '../../src/testdata/data.json';

for (let i = 0; i < data.TestCase02.length; i++) {
  test(`Validate login to application using different users ${data.TestCase02[i].number}`, async ({
    page,
  }) => {
    const poManager = new pageObjectManager(page);

    await poManager.login.gotoApplication();
    await poManager.login.logintoApplication();
    await poManager.login.assertionForLogin();
    await poManager.search.searchForUser(
      data.TestCase02[i].User,
      data.TestCase02[i].expectName,
    );
  });
}
