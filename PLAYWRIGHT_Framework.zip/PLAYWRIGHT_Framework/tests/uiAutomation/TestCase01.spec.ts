import { test } from '@playwright/test';
import { pageObjectManager } from '../../src/pageobjects/pageObjectManager';
import * as data from '../../src/testdata/data.json';

for (let i = 0; i < data.TestCase01.length; i++) {
  test(`Validate with different ${data.TestCase01[i].number}`, async ({
    page,
  }) => {
    const poManager = new pageObjectManager(page);

    await poManager.login.gotoApplication();
    await poManager.login.logintoApplication();
    await poManager.login.assertionForLogin();
    await poManager.search.searchForUser(
      data.TestCase01[i].User,
      data.TestCase01[i].expectName,
    );
  });
}
