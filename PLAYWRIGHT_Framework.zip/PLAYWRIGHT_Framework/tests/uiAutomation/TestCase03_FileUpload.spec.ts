import { pageObjectManager } from '../../src/pageobjects/pageObjectManager';
import { test } from '@playwright/test';

test('Test script to Upload a Single File', async ({ page }) => {
  const pageObject = new pageObjectManager(page);

  await pageObject.fileUpload.gotoSingleFileUploadApplication();
  await pageObject.fileUpload.fileUpload();
});
test('Test script to Upload Multiple Files', async ({ page }) => {
  const pageObject = new pageObjectManager(page);

  await pageObject.fileUpload.gotoMultiFileUploadApplication();
  await pageObject.fileUpload.multipleFileUpload();
});
