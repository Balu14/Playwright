import { test } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';

test('Login to the Application', async ({ page }) => {
  const login = new loginPage(page);
  // const expectedValue = 'Punched';

  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLogin();
});
