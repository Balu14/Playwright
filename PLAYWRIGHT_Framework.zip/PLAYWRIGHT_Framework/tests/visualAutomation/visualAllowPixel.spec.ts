import { test, expect } from '@playwright/test';
import { loginPage } from '../../src/pageobjects/loginPage';

test('Visual testing the of Home page', async ({ page }) => {
  const login = new loginPage(page);

  await login.gotoApplication();
  await login.logintoApplication();
  await login.assertionForLogin();
  await expect(page).toHaveScreenshot({ maxDiffPixels: 100 });
});
