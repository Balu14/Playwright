import { test, expect } from '@playwright/test';

test('Visual testing the of Home page', async ({ page }) => {
  await page.goto('https://www.amazon.in/');
  await expect(page).toHaveScreenshot({ maxDiffPixels: 100 });
});
