import { LoginPageObjects } from '../objectRepository/LoginPageObjects';
import { Page } from '@playwright/test';
import { config } from '../support/config';
import { webActions } from '../../lib/webActions';
import { testConfig } from '../../testConfig';
import { assertionLibrary } from '../../lib/assertionLibrary';

let webAction: webActions;
let expectAssertion: assertionLibrary;

export class loginPage extends LoginPageObjects {
  readonly page: Page;

  constructor(page: Page) {
    super();
    this.page = page;
    webAction = new webActions(this.page);
    expectAssertion = new assertionLibrary(this.page);
  }

  async gotoApplication() {
    await webAction.navigateToURL(config.BASE_URL);
    await webAction.waitForPageNavigation(LoginPageObjects.load);
  }

  async logintoApplication() {
    await webAction.enterElementText(
      LoginPageObjects.userName,
      testConfig.username,
    );
    await webAction.enterElementText(
      LoginPageObjects.passWord,
      testConfig.password,
    );
    await webAction.clickElement(LoginPageObjects.submit);
  }
  async assertionForLogin() {
    // await webAction.takeScreenShot();
    await expectAssertion.verifyElementContainsText(
      LoginPageObjects.punchOutValue,
      LoginPageObjects.Punched,
    );
  }
  async assertionForLoginWithScreenShot() {
    await webAction.takeScreenShot();
    await expectAssertion.verifyElementContainsText(
      LoginPageObjects.punchOutValue,
      LoginPageObjects.Punched,
    );
  }
}
