import { FileUploadObjects } from '../objectRepository/FileUploadObjects';
import { webActions } from '../../lib/webActions';
import { Page } from 'playwright';

let webaction: webActions;

export class fileUploadPage extends FileUploadObjects {
  readonly page: Page;

  constructor(page: Page) {
    super();
    this.page = page;
    webaction = new webActions(this.page);
  }

  async gotoSingleFileUploadApplication() {
    await this.page.goto(FileUploadObjects.singleFileUploadURL);
  }

  async fileUpload() {
    await webaction.clickElement(FileUploadObjects.closeButton);
    await webaction.fileUpload(
      FileUploadObjects.fileUploadButton,
      FileUploadObjects.fileName,
    );
    await webaction.clickElement(FileUploadObjects.successButton);
  }

  async gotoMultiFileUploadApplication() {
    await this.page.goto(FileUploadObjects.fileUploadURL);
  }
  async multipleFileUpload() {
    await webaction.filesUpload(
      FileUploadObjects.fileUploadButton,
      FileUploadObjects.filesName,
    );
    await webaction.clickElement(FileUploadObjects.submitButton);
  }
}
