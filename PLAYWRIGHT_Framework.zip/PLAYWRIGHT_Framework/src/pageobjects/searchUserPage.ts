import { SearchUserPageObjects } from '../objectRepository/SearchUserPageObjects';
import { Locator, Page } from '@playwright/test';
import { webActions } from '../../lib/webActions';
import { assertionLibrary } from '../../lib/assertionLibrary';

let webAction: webActions;
let expectAssertion: assertionLibrary;

export class searchUserPage extends SearchUserPageObjects {
  readonly page: Page;
  constructor(page: Page) {
    super();
    this.page = page;
    webAction = new webActions(this.page);
    expectAssertion = new assertionLibrary(this.page);
  }
  async searchForUser(user: string, expectName: string) {
    await webAction.clickElement(SearchUserPageObjects.adminButton);
    await webAction.enterElementText(SearchUserPageObjects.searchInput, user);
    await webAction.waitForContainsSelectorsLocator(user);
    await webAction.clickOnGetByRoleElement(user);
    await webAction.clickElement(SearchUserPageObjects.searchButton);
    await expectAssertion.verifyElementContainsText(
      SearchUserPageObjects.empName,
      expectName,
    );
  }
}
