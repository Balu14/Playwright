import { Page } from 'playwright';
import { loginPage } from './loginPage';
import { searchUserPage } from './searchUserPage';
import { fileUploadPage } from './fileUpoadPage';

export class pageObjectManager {
  readonly page: Page;
  login: loginPage;
  search: searchUserPage;
  fileUpload: fileUploadPage;
  constructor(page: Page) {
    this.page = page;
    this.login = new loginPage(this.page);
    this.search = new searchUserPage(this.page);
    this.fileUpload = new fileUploadPage(this.page);
  }
}
