export class FileUploadObjects {
  protected static fileUploadURL = 'http://autopract.com/selenium/upload1/';
  protected static singleFileUploadURL = 'http://www.autopract.com';
  protected static fileUploadButton = 'input[type="file"]';

  protected static fileName = 'files/wright.png';

  protected static filesName = ['files/play.png', 'files/wright.png'];

  protected static submitButton = 'button[type="submit"]';

  protected static closeButton = '.close';

  protected static successButton = '.btn.btn-success';
}
