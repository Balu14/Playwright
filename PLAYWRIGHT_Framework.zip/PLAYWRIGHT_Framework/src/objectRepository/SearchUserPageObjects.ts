export class SearchUserPageObjects {
  protected static adminButton =
    '//a[@href="/web/index.php/admin/viewAdminModule"]';
  protected static searchInput = 'input[placeholder*="Type for hints"]';
  protected static searchButton = '//button[@type="submit"]';
  protected static empName =
    '(//div[@class="oxd-table-cell oxd-padding-cell"])[4]';
}
