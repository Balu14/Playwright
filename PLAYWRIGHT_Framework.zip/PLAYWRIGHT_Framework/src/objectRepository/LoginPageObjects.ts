export class LoginPageObjects {
  protected static userName = `input[name="username"]`;
  protected static passWord = `input[name="password"]`;
  protected static submit = `button[type="submit"]`;
  protected static punchOutValue = `p[class*="oxd-text oxd-text--p orangehrm-attendance-card-st"]`;
  protected static load = `load`;
  protected static Punched = 'Punched';
}
