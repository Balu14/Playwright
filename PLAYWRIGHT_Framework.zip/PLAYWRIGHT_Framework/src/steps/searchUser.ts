import { ICustomWorld } from '../support/custom-world';
import { Given, When, Then } from '@cucumber/cucumber';
import { loginPage } from '../pageobjects/loginPage';
import { searchUserPage } from '../pageobjects/searchUserPage';

Given(
  'Serach for the User in Applicaiton',
  async function (this: ICustomWorld) {
    const login = new loginPage(this.page!);
    await login.gotoApplication();
  },
);

When(
  'User Enter Valid UserName and Valid Password in the login page',
  async function (this: ICustomWorld) {
    const login = new loginPage(this.page!);
    await login.logintoApplication();
  },
);

Then(
  'Search for User {string} in Admin Tab Expected Name {string}',
  async function (this: ICustomWorld, User: string, expectName: string) {
    const search = new searchUserPage(this.page!);
    await search.searchForUser(User, expectName);
  },
);
