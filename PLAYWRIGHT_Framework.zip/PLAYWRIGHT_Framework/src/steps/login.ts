import { ICustomWorld } from '../support/custom-world';
import { Given, When, Then } from '@cucumber/cucumber';
import { loginPage } from '../pageobjects/loginPage';

Given('Go to the OrangeHRM application', async function (this: ICustomWorld) {
  const login = new loginPage(this.page!);
  await login.gotoApplication();
});

When('User enter UserName and Password', async function (this: ICustomWorld) {
  const login = new loginPage(this.page!);
  await login.logintoApplication();
});

Then(
  'User should able to login to the applicaiton Successfully',
  async function (this: ICustomWorld) {
    const login = new loginPage(this.page!);
    await login.assertionForLogin();
  },
);
